SunmiPrinterDemo
==========
### 
Developer documentation : https://docs.sunmi.com
###
We strongly recommend developers to use Android Studio to develop.The demo for Android Studio has full functionality, such as printing barcodes, printing qr code, printing text, printing pictures and printing tables.
###
Demo for Eclipse:https://github.com/shangmisunmi/SunmiPrinterDemo-Eclipse-/tree/master/PrinterTestDemo_eclipse/src/com/test/printertestdemo  

Instruction
----------
* Project contains four demos, and be careful to use them in accordance with the corresponding machine model
* The main difference among them is the aidl files, you can find them from : http://ota.cdn.sunmi.com/DOC/resource/re_cn/AIDL.rar
* How to import?
    
    Convert to project in the Android Studio, and build  a Aidl folder under the "src/main" file
    ![](http://upload-images.jianshu.io/upload_images/1739458-05362df2ccd280cb.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
